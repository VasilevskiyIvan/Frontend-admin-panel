import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Language from '../components/Language';
import Photos from '../components/Photos';
import Videos from '../components/Videos';
import OtherFiles from '../components/OtherFiles';
import MenuSection from '../components/MenuSection';
import './AddBlockPage.css';

const AddBlockPage = () => {
  const navigate = useNavigate();
  const [photos, setPhotos] = useState([]);
  const [videos, setVideos] = useState([]);
  const [otherFiles, setOtherFiles] = useState([]);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [languages, setLanguages] = useState(null);

  const handleAddMedia = (type, files) => {
    if (type === 'image') setPhotos(prev => [...prev, ...files]);
    if (type === 'video') setVideos(prev => [...prev, ...files]);
    if (type === 'other') setOtherFiles(prev => [...prev, ...files]);
  };

  const handleDeleteMedia = (type, index) => {
    if (type === 'image') {
      setPhotos(prev => prev.filter((_, i) => i !== index));
      setCurrentPhotoIndex(0);
    }
    if (type === 'video') {
      setVideos(prev => prev.filter((_, i) => i !== index));
      setCurrentVideoIndex(0);
    }
    if (type === 'other') {
      setOtherFiles(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleSaveBlock = async () => {
    if (!languages) {
      alert('Пожалуйста, заполните хотя бы один язык');
      return;
    }

    try {
      const blockResponse = await fetch('/api/blocks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ languages })
      });
      
      if (!blockResponse.ok) throw new Error('Ошибка создания блока');
      const { id: blockId } = await blockResponse.json();

      const uploadMedia = async (type, files) => {
        if (files.length === 0) return;
        const formData = new FormData();
        files.forEach(f => formData.append(type, f.file));
        await fetch(`/api/blocks/${blockId}/${type}`, {
          method: 'POST',
          body: formData
        });
      };

      await Promise.all([
        uploadMedia('photos', photos),
        uploadMedia('videos', videos),
        uploadMedia('files', otherFiles)
      ]);

      navigate('/blocks');
    } catch (error) {
      alert('Ошибка сохранения блока: ' + error.message);
    }
  };

  return (
    <div className="page">
      <MenuSection />
      <div className="add-block-page">
        <Header title="Добавить новый блок" />

        <div className="container">
          <Language onChange={setLanguages} />
          
          <Photos
            files={photos}
            currentIndex={currentPhotoIndex}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
            onChangeIndex={setCurrentPhotoIndex}
          />
          <Videos
            files={videos}
            currentIndex={currentVideoIndex}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
            onChangeIndex={setCurrentVideoIndex}
          />
          <OtherFiles
            files={otherFiles}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
          />

          <button className="save-button" onClick={handleSaveBlock}>
            Сохранить блок
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddBlockPage;