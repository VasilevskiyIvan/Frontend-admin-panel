// import { useState, useEffect } from 'react'
// import { Link } from 'react-router-dom'
// import Header from '../components/Header'
// import MenuSection from '../components/MenuSection'
// import './BlockSelectPage.css'

// const BlockSelectPage = () => {
//   const [blocks, setBlocks] = useState([])
//   const [isLoading, setIsLoading] = useState(true)
//   const [error, setError] = useState(null)

//   useEffect(() => {
//     const fetchBlocks = async () => {
//       try {
//         const response = await fetch('/api/blocks')
//         if (!response.ok) throw new Error('Ошибка загрузки')
//         const data = await response.json()
//         setBlocks(data)
//       } catch (err) {
//         setError(err.message)
//       } finally {
//         setIsLoading(false)
//       }
//     }
//     fetchBlocks()
//   }, [])

//   if (isLoading) return <div className="loading">Загрузка блоков...</div>
//   if (error) return <div className="error">Ошибка: {error}</div>

//   return (
//     <div className="page">
//       <MenuSection />
//       <div className="block-select-page">
//         <Header title="Выберите блок для редактирования" />
//         <div className="container">
//           <div className="blocks-grid">
//             {blocks.map(block => (
//               <div key={block.id} className="block-card">
//                 <h3>{block.languages.ru.title || 'Без названия'}</h3>
//                 <div className="block-actions">
//                   <Link to={`/blocks/edit/${block.id}`} className="edit-button">
//                     Редактировать
//                   </Link>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default BlockSelectPage;

import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import Header from '../components/Header'
import MenuSection from '../components/MenuSection'
import './BlockSelectPage.css'

const BlockSelectPage = () => {
  const [blocks, setBlocks] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  const mockBlocks = [
    {
      id: '1',
      languages: {
        ru: { title: 'Тестовый блок 1', content: 'Содержание на русском' },
        en: { title: 'Test block 1', content: 'English content' },
        zh: { title: '测试块1', content: '中文内容' },
        ar: { title: 'كتلة الاختبار 1', content: 'المحتوى العربي' }
      }
    },
    {
      id: '2',
      languages: {
        ru: { title: 'Тестовый блок 2', content: 'Другое содержание' },
        en: { title: 'Test block 2', content: 'Other content' },
        zh: { title: '测试块2', content: '其他内容' },
        ar: { title: 'كتلة الاختبار 2', content: 'محتوى آخر' }
      }
    }
  ];
  
  useEffect(() => {
    const fetchBlocks = async () => {
      try {
        setBlocks(mockBlocks);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchBlocks()
  }, [])

  if (isLoading) return <div className="loading">Загрузка блоков...</div>
  if (error) return <div className="error">Ошибка: {error}</div>

  return (
    <div className="page">
      <MenuSection />
      <div className="block-select-page">
        <Header title="Выберите блок для редактирования" />
        <div className="container">
          <div className="blocks-grid">
            {blocks.map(block => (
              <div key={block.id} className="block-card">
                <h3>{block.languages.ru.title || 'Без названия'}</h3>
                <div className="block-actions">
                  <Link to={`/blocks/edit/${block.id}`} className="edit-button">
                    Редактировать
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlockSelectPage;