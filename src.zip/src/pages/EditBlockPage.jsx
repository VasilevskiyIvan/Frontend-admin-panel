import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import Language from '../components/Language';
import Photos from '../components/Photos';
import Videos from '../components/Videos';
import OtherFiles from '../components/OtherFiles';
import MenuSection from '../components/MenuSection';

const EditBlockPage = () => {
  const { blockId } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [photos, setPhotos] = useState([]);
  const [videos, setVideos] = useState([]);
  const [otherFiles, setOtherFiles] = useState([]);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [languages, setLanguages] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [blockRes, mediaRes] = await Promise.all([
          fetch(`/api/blocks/${blockId}`),
          fetch(`/api/blocks/${blockId}/media`)
        ]);

        const blockData = await blockRes.json();
        const mediaData = await mediaRes.json();

        setLanguages(blockData.languages);
        setPhotos(mediaData.photos.map(url => ({ url, isExisting: true })));
        setVideos(mediaData.videos.map(url => ({ url, isExisting: true })));
        setOtherFiles(mediaData.files.map(url => ({
          url,
          name: url.split('/').pop(),
          isExisting: true
        })));

      } catch (error) {
        console.error('Ошибка загрузки:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [blockId]);

  const handleDelete = async () => {
    if (window.confirm('Удалить блок навсегда?')) {
      await fetch(`/api/blocks/${blockId}`, { method: 'DELETE' });
      navigate('/blocks/select');
    }
  };

  const handleSave = async () => {
    try {
      await fetch(`/api/blocks/${blockId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ languages })
      });

      const saveMedia = async (type, files) => {
        const formData = new FormData();
        files.filter(f => !f.isExisting).forEach(f => formData.append(type, f.file));
        if (formData.entries().next().done) return;
        await fetch(`/api/blocks/${blockId}/${type}`, { method: 'POST', body: formData });
      };

      await Promise.all([
        saveMedia('photos', photos),
        saveMedia('videos', videos),
        saveMedia('files', otherFiles)
      ]);

      navigate('/blocks');
    } catch (error) {
      console.error('Ошибка сохранения:', error);
    }
  };

  const handleAddMedia = (type, files) => {
    const filesToAdd = files.slice(0, 5);

    if (type === 'image') setPhotos(prev => [...prev, ...filesToAdd]);
    if (type === 'video') setVideos(prev => [...prev, ...filesToAdd]);
    if (type === 'other') setOtherFiles(prev => [...prev, ...filesToAdd]);
  };

  const handleDeleteMedia = (type, index) => {
    if (type === 'image') {
      setPhotos(prev => prev.filter((_, i) => i !== index));
      setCurrentPhotoIndex(0);
    }
    if (type === 'video') {
      setVideos(prev => prev.filter((_, i) => i !== index));
      setCurrentVideoIndex(0);
    }
    if (type === 'other') {
      setOtherFiles(prev => prev.filter((_, i) => i !== index));
    }
  };

  if (isLoading) return <div className="loading">Загрузка...</div>;

  return (
    <div className="page">
      <MenuSection />
      <div className="add-block-page">
        <Header title="Редактирование блока" onDelete={handleDelete} />
        <div className="container">
          <Language initialLanguages={languages} onChange={setLanguages} />

          <Photos
            files={photos}
            currentIndex={currentPhotoIndex}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
            onChangeIndex={setCurrentPhotoIndex}
          />
          <Videos
            files={videos}
            currentIndex={currentVideoIndex}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
            onChangeIndex={setCurrentVideoIndex}
          />
          <OtherFiles
            files={otherFiles}
            onAdd={handleAddMedia}
            onDelete={handleDeleteMedia}
          />

          <button className="save-button" onClick={handleSave}>
            Сохранить изменения
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditBlockPage;