import { Link } from 'react-router-dom'
import Hierarchy from '../components/Hierarchy/index'
import MenuSection from '../components/MenuSection'
import Header from '../components/Header'
import './HomePage.css'

const HomePage = () => {

  const hierarchyData = [
    { parent_id: null, children_id: 1, children_title: "Блок 1. Содержимое блока 1..." },
    { parent_id: 1, children_id: 2, children_title: "Блок 2. Содержимое блока 2..." },
    { parent_id: 1, children_id: 3, children_title: "Блок 3. Содержимое блока 3..." },
    { parent_id: 2, children_id: 4, children_title: "Блок 4. Содержимое блока 4..." },
    { parent_id: 2, children_id: 5, children_title: "Блок 5. Содержимое блока 5..." },
    { parent_id: 3, children_id: 6, children_title: "Блок 6. Содержимое блока 6..." },
    { parent_id: 3, children_id: 7, children_title: "Блок 7. Содержимое блока 7..." },
    { parent_id: 4, children_id: 8, children_title: "Блок 8. Содержимое блока 8..." },
    { parent_id: 4, children_id: 9, children_title: "Блок 9. Содержимое блока 9..." },
    { parent_id: 5, children_id: 10, children_title: "Блок 10. Содержимое блока 10..." },
    { parent_id: 5, children_id: 11, children_title: "Блок 11. Содержимое блока 11..." },
    { parent_id: 6, children_id: 12, children_title: "Блок 12. Содержимое блока 12..." },
    { parent_id: 6, children_id: 13, children_title: "Блок 13. Содержимое блока 13..." },
    { parent_id: 7, children_id: 14, children_title: "Блок 14. Содержимое блока 14..." },
    { parent_id: 7, children_id: 15, children_title: "Блок 15. Содержимое блока 15..." },
    { parent_id: 8, children_id: 16, children_title: "Блок 16. Содержимое блока 16..." },
    { parent_id: 8, children_id: 17, children_title: "Блок 17. Содержимое блока 17..." },
    { parent_id: 9, children_id: 18, children_title: "Блок 18. Содержимое блока 18..." },
    { parent_id: 10, children_id: 19, children_title: "Блок 19. Содержимое блока 19..." },
    { parent_id: 11, children_id: 20, children_title: "Блок 20. Содержимое блока 20..." },
    { parent_id: null, children_id: 21, children_title: "Блок 21. Содержимое блока 21..." },
    { parent_id: 21, children_id: 22, children_title: "Блок 22. Содержимое блока 22..." },
    { parent_id: 21, children_id: 23, children_title: "Блок 23. Содержимое блока 23..." },
    { parent_id: 22, children_id: 24, children_title: "Блок 24. Содержимое блока 24..." },
    { parent_id: 22, children_id: 25, children_title: "Блок 25. Содержимое блока 25..." },
    { parent_id: 23, children_id: 26, children_title: "Блок 26. Содержимое блока 26..." },
    { parent_id: 23, children_id: 27, children_title: "Блок 27. Содержимое блока 27..." },
    { parent_id: 24, children_id: 28, children_title: "Блок 28. Содержимое блока 28..." },
    { parent_id: 24, children_id: 29, children_title: "Блок 29. Содержимое блока 29..." },
    { parent_id: 25, children_id: 210, children_title: "Блок 30. Содержимое блока 30..." },
    { parent_id: 25, children_id: 211, children_title: "Блок 31. Содержимое блока 31..." },
    { parent_id: 26, children_id: 212, children_title: "Блок 32. Содержимое блока 32..." },
    { parent_id: 26, children_id: 213, children_title: "Блок 33. Содержимое блока 33..." },
    { parent_id: 27, children_id: 214, children_title: "Блок 34. Содержимое блока 34..." },
    { parent_id: 27, children_id: 215, children_title: "Блок 35. Содержимое блока 35..." },
    { parent_id: 28, children_id: 216, children_title: "Блок 36. Содержимое блока 36..." },
    { parent_id: 28, children_id: 217, children_title: "Блок 37. Содержимое блока 37..." },
    { parent_id: 29, children_id: 218, children_title: "Блок 38. Содержимое блока 38..." },
    { parent_id: 210, children_id: 219, children_title: "Блок 39. Содержимое блока 39..." },
    { parent_id: 211, children_id: 220, children_title: "Блок 40. Содержимое блока 40..." },
    { parent_id: 214, children_id: 240, children_title: "Блок 41. Содержимое блока 41..." },
    { parent_id: 240, children_id: 241, children_title: "Блок 42. Содержимое блока 42..." },
    { parent_id: 241, children_id: 242, children_title: "Блок 43. Содержимое блока 43..." },
    { parent_id: 242, children_id: 243, children_title: "Блок 44. Содержимое блока 44..." },
    { parent_id: 243, children_id: 244, children_title: "Блок 45. Содержимое блока 45..." },
    { parent_id: 244, children_id: 245, children_title: "Блок 46. Содержимое блока 46..." },
  ];


  return (
    <div className="page">
      <MenuSection />

      <div className="hierarchy">
        <Header title="Иерархия блоков" />
        <Hierarchy data={hierarchyData} />
      </div>
    </div>
  )
}

export default HomePage