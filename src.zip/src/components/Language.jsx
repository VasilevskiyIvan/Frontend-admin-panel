import { useState, useEffect } from 'react';
import './Language.css';
import Indicators from './Indicators';

const Language = ({ initialLanguages, onChange }) => {
  const [selectedLanguage, setSelectedLanguage] = useState('ru');
  const [languages, setLanguages] = useState({
    ru: { title: '', content: '' },
    en: { title: '', content: '' },
    zh: { title: '', content: '' },
    ar: { title: '', content: '' }
  });

  useEffect(() => {
    if (initialLanguages) {
      setLanguages(initialLanguages);
    }
  }, [initialLanguages]);

  const handleLanguageSelect = (lang) => {
    setSelectedLanguage(lang);
  };

  const handleLanguageChange = (lang, field, value) => {
    const updatedLanguages = {
      ...languages,
      [lang]: { ...languages[lang], [field]: value }
    };
    setLanguages(updatedLanguages);
    if (onChange) {
      onChange(updatedLanguages);
    }
  };

  const getIndicatorStatus = (lang) => {
    const { title, content } = languages[lang];
    if (!title && !content) return 'danger';
    if (title && content) return 'success';
    return 'warning';
  };

  return (
    <div className="language-section">
      <Indicators 
        languages={['ru', 'en', 'zh', 'ar']} 
        getStatus={getIndicatorStatus} 
      />
      
      <div className="language-selector">
        <select 
          value={selectedLanguage} 
          onChange={(e) => handleLanguageSelect(e.target.value)}
        >
          <option value="ru">Русский</option>
          <option value="en">English</option>
          <option value="zh">中文</option>
          <option value="ar">العربية</option>
        </select>
      </div>

      <div className="language-inputs">
        <input
          type="text"
          placeholder="Заголовок"
          value={languages[selectedLanguage]?.title || ''}
          onChange={(e) => handleLanguageChange(selectedLanguage, 'title', e.target.value)}
        />
        <textarea
          placeholder="Описание"
          value={languages[selectedLanguage]?.content || ''}
          onChange={(e) => handleLanguageChange(selectedLanguage, 'content', e.target.value)}
        />
      </div>
    </div>
  );
};

export default Language;