import { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  // Проверка аутентификации при загрузке приложения
  // Используем эндпоинт /api/auth/check для получения данных пользователя
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/api/auth/check'); 
        if (response.ok) {
          const userData = await response.json();
          setUser(userData); 
        } else {
          // Если токен невалиден или отсутствует, пользователь не аутентифицирован
          setUser(null);
        }
      } catch (error) {
        console.error('Ошибка при проверке статуса аутентификации:', error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    checkAuthStatus();
  }, []);

  const login = async (username, password) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        // После успешного входа, бекенд уже установил куку.
        // Теперь делаем запрос на /api/auth/check, чтобы получить актуальные данные пользователя.
        const userResponse = await fetch('/api/auth/check');
        if (userResponse.ok) {
          const userData = await userResponse.json();
          setUser(userData);
          return true;
        } else {
          console.error('Не удалось получить данные пользователя после входа.');
          setUser(null);
          return false;
        }
      } else {
        // Обработка ошибок, например, неверные учетные данные (response.status === 401)
        // Можно прочитать сообщение об ошибке, если бекенд его возвращает
        const errorData = await response.json(); // Попытаемся получить JSON-ответ
        console.error('Ошибка входа:', errorData.detail || 'Неизвестная ошибка');
        return false;
      }
    } catch (error) {
      console.error('Сетевая ошибка при входе:', error);
      return false;
    }
  };

  const logout = async () => {
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST' });
      if (!response.ok) {
        console.error('Ошибка при выходе из системы на сервере:', response.statusText);
      }
    } catch (error) {
      console.error('Сетевая ошибка при выходе:', error);
    } finally {
      setUser(null); // Очищаем пользователя на клиенте
      navigate('/login'); // Перенаправляем на страницу входа
    }
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {!isLoading && children} 
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}